// ==========================================
// GUÍAS: ELIMINAR SOLO LA PRIMERA VEZ
// ==========================================

PlayerEvents.tick(event => {
    const player = event.player

    if (!player.persistentData.getBoolean('guiasEliminadas')) {

        // Argentina's Delight Reborn
        player.inventory.clear('argentinasdelightreborn:brief_guide')

        // Starcatcher
        player.inventory.clear('starcatcher:starcatcher_guide')

        // Marcar como procesado
        player.persistentData.putBoolean('guiasEliminadas', true)
    }
})
